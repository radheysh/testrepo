/**
 * 
 */
package com.fti.usdg.track.trace.dto;

/**
 * @author Anup 
 *
 */
public class UserDataHolder {

	private String groupName = null;
	private String userUUID = null;
	/**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}
	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	/**
	 * @return the userUUID
	 */
	public String getUserUUID() {
		return userUUID;
	}
	/**
	 * @param userUUID the userUUID to set
	 */
	public void setUserUUID(String userUUID) {
		this.userUUID = userUUID;
	}		
	
	
	
}
