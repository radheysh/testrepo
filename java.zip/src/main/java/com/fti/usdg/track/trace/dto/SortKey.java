/**
 * 
 */
package com.fti.usdg.track.trace.dto;

/**
 * @author Anup Kumar Gupta
 * @date 05-Jan-2020
 */
public class SortKey {

	private String attibName = null;
	private String sortType = null;
	
	/**
	 * @return the attibName
	 */
	public String getAttibName() {
		return attibName;
	}
	/**
	 * @param attibName the attibName to set
	 */
	public void setAttibName(String attibName) {
		this.attibName = attibName;
	}
	/**
	 * @return the sortType
	 */
	public String getSortType() {
		return sortType;
	}
	/**
	 * @param sortType the sortType to set
	 */
	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
	
	
}
